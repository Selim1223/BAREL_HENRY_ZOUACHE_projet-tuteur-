-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 07, 2022 at 09:36 AM
-- Server version: 5.7.36
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
CREATE TABLE IF NOT EXISTS `info` (
  `Info_id` int(3) NOT NULL,
  `Info_label` varchar(210) DEFAULT NULL,
  PRIMARY KEY (`Info_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`Info_id`, `Info_label`) VALUES
(1, 'Il y a environ 1,9 milliard de moutons et 19,6 milliard de poulets sur terre'),
(2, 'Il existe 195 pays dans le monde'),
(3, 'Si Jeff Bezos dépensait chaque jour 1 millions de dollars, il lui faudrait plus de 500 ans pour tout dépenser'),
(4, 'Netflix a été fondé en 1997, soit 1 an avant google'),
(5, 'L’un des ingrédients du Coca Cola était de la cocaïne, mais elle a été retirée de la recette en 1929'),
(6, 'Chaque année, plus de personnes meurent par une noix de coco qui tombe d’un arbre que par des attaques de requins'),
(7, 'Les soldats de l’armée chinoise ont des aiguilles sur le col de leur chemise pour qu’ils tiennent leur tête bien droite'),
(8, 'Notre sang fait le tour de notre corps 1000 fois par jour, incroyable n\'est-ce pas!'),
(9, 'Un crayon basique peut écrire jusqu’à 45 000 mots'),
(10, 'Le mot karaoké veut dire « Orchestre vide');

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
CREATE TABLE IF NOT EXISTS `question` (
  `Question_id` int(3) NOT NULL,
  `Question_label` varchar(210) DEFAULT NULL,
  `Niveau` int(3) NOT NULL,
  `réponse` int(11) NOT NULL,
  PRIMARY KEY (`Question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`Question_id`, `Question_label`, `Niveau`, `réponse`) VALUES
(101, 'Quelle est la capitale de l\'Espagne ?', 1, 101),
(102, 'Quelle est la capitale de la suisse ?', 1, 102),
(103, 'Quelle est la capitale du Japon ?', 1, 103),
(104, 'Quelle est l\'année du début de la guerre froide ?', 1, 104),
(105, '2+3*2', 1, 105),
(106, 'Combien y a-t-il de planètes dans notre système solaire ?', 1, 106),
(107, 'Combien y-a-t-il d\'étoile(s) dans notre système solaire', 1, 107),
(108, 'Quelle pièce est absolument à protéger dans un jeu d’échec ?', 1, 108),
(109, 'Quelle année a suivi l’an 1 avant JC ?', 1, 109),
(110, 'Quelle est la capitale des Etats-Unis ?', 1, 110),
(111, 'Quelle est la capitale de l\'Italie ?', 1, 111),
(112, 'Quelle est la capitale du Mexique ?', 1, 112),
(113, 'Combien y a-t-il de signes astrologiques chinois ?', 1, 113),
(114, 'De qui est amoureux Juliette ?', 1, 114),
(115, 'Complétez ce célèbre slogan \'Just ... it\'', 1, 115),
(116, 'Qui a mis le premier le pied sur la Lune ?', 1, 116),
(117, 'De combien de sens fondamentaux est pourvus l\'Homme?', 1, 117),
(118, 'Qui est l\'ennemie de Mario ?', 1, 118),
(119, 'Quelles sont les 2 couleurs principales représentant Yoshi ?', 1, 119),
(201, 'Qui est l\'auteur du Corbeau et du Renard ?', 2, 201),
(202, 'Quel est le sommet le plus haut de France ?', 2, 202),
(203, 'De combien de syllabes est composées un alexandrin ?', 2, 203),
(204, 'Qui a écrit les misérables ?', 2, 204),
(205, 'De quoi se nourrissent les manchots ?', 2, 205),
(206, 'De quel type de planète est Jupiter ?', 2, 206),
(207, 'Comment nomme-t-on en Russie quelqu’un qui voyage dans l’espace ?', 2, 207),
(208, 'Combien de régions, la France métropolitaine en contient-elle ?', 2, 208),
(209, 'En quelle année Jacque Chirac est-il devenu pour la première fois président de la France ?', 2, 209),
(210, 'Quelle planète est surnommée la planète rouge ?', 2, 210),
(211, 'Quand a eu lieu la prise de la bastille ?', 2, 211),
(212, 'Dans quelle république sômmes-nous actuellement ?', 2, 212),
(213, 'Qui était le grand dictateur de l\'URSS durant la seconde guerre mondiale ?', 2, 213),
(214, 'Parmis Hitler, la seconde guerre mondiale ou le coronavirus, qui a fait le plus de mort ?', 2, 214),
(215, 'Vrai ou faux, l\'Inde est le pays le plus peuplé du monde ?', 2, 215),
(216, 'Dans la mythologie grecque, qui possède un trident et est le dieu des mers?', 2, 216),
(217, 'Quel est l\'animal le plus grand encore existant sur terre ?', 2, 217),
(218, 'Comment appelle-t-on les commbattants français de la première guerre mondiale ?', 2, 218),
(301, 'Quel est le sommet le plus haut du monde ?', 3, 301),
(302, 'Comment se nomme notre galaxie ?', 3, 302),
(303, 'Quelle ville est surnommé « big Apple » aux USA ?', 3, 303),
(304, 'Quelle est l\'année du début de la guerre froide ?', 3, 304),
(305, 'Comment appelle-t-on la lumière qui se rapproche le plus de la lumière du soleil ?', 3, 305),
(306, 'Quel est le nom officiel du terrain de tennis ?', 3, 306),
(307, 'Quel est le pays natal de Wolfgang Amadeus Mozart ?', 3, 307),
(308, 'Quel pays a inventé la poudre a canon ?', 3, 308),
(309, 'Combien y a-t-il de joueurs sur le terrain dans une équipe de base-ball ?', 3, 309),
(310, 'Comment appelle-t-on un bateau à trois coques ?', 3, 310),
(311, 'Quelle est, environ, la vitesse de la lumière ?', 3, 311),
(312, 'En quelle année la machine à vapeur a-t-elle été inventé ?', 3, 312),
(313, 'En quelle année l\'euro a-t-elle été nommé comme monnaie unique en Europe ?', 3, 313),
(314, 'Parmis ces races de chien, laquelle n\'en est pas une ?', 3, 314),
(315, 'Que signifie le therme NFT ?', 3, 315),
(401, 'En quelle année a été fondé Google ?', 4, 401),
(402, 'Quel est le 2ème nom de l’hippocampe (surnom) ?', 4, 402),
(403, 'Qui raconte les aventures de Sherlock Holmes ?', 4, 403),
(404, 'Quel fleuve a le plus gros débit au monde ?', 4, 404),
(405, 'Quel est le diamètre du Soleil ?', 4, 405),
(406, 'Qu’est-ce qu’une géante gazeuse ?', 4, 406),
(407, 'Qu’est-ce qu’une exoplanète ?', 4, 407),
(408, 'Comment nomme-t-on un nuage de gaz et de poussières répandu dans l’espace interstellaire ?', 4, 408),
(409, 'En quelle année a eu lieu la chute du mur de Berlin', 4, 409),
(410, 'Quel est le nom du roi Arthur', 4, 410),
(411, 'Où est né Mozart ?', 4, 411),
(412, 'Quel est le nommbre total d\'abonnée à Netflix dans le monde ? (5 millions près)', 4, 412),
(413, 'Parmi ces villes, laquelle est à la fois en Asie et en Europe ?', 4, 413),
(414, 'Quelle est la voiture la plus vendu au monde ?', 4, 414),
(415, 'Citez 3 des 8 rennes du père Noël', 4, 415),
(416, 'Dans la mythologie grecque, qui est la déesse de la guerre et de la sagesse ?', 4, 416),
(417, 'Dans la mythologie grecque, qui est le dieu des enfers ?', 4, 417),
(501, 'Quelle est le dernier album de Britney Spears ?', 5, 501),
(502, 'Qui fut le quarantième président des USA ?', 5, 502),
(503, 'Quel est le plus long fleuve d\'Europe occidentale ?', 5, 503),
(504, 'Que collectionne un conchyophile ?', 5, 504),
(505, 'Qui est l\'héroïne de \'Notre-Dame de Paris\' ?', 5, 505),
(506, 'Parmis ces propositions, déterminez lequel de ces monuments ne fait pas partie des 12 anciennes merveilles du monde', 5, 506),
(507, 'Lequel de ces monuments fait partie des nouvelles meirveilles du monde ?', 5, 507),
(508, 'Quel a été le dernier monarque à avoir régné sur la France ?', 5, 508),
(509, 'En quelle année la 4ème république a-t-elle commencé ?', 5, 509),
(510, 'En quelle année fut signé la loi de séparationn de l\'église et de l\'état ?', 5, 510),
(511, 'Quel acte (assassinat) a déclanché la première guerre mondiale ?', 5, 511),
(512, 'En quelle année eu la célèbre bataille de verdun ?', 5, 512),
(513, 'Laquelle de ces iles françaises est la plus grande ?', 5, 513),
(514, 'Un bateau sur l’eau ne coule pas, c’est grâce…', 5, 514),
(515, 'Avec la laine de quel animal fait-on du cachemire ?', 5, 515),
(516, 'Quel est le pays le plus petit du monde ?', 5, 516),
(517, 'Dans la mythologie grecque, qui est le dieu du feu, des forges ?', 5, 517),
(518, 'Comment se nomme le hibou de companie d\'Harry Poter', 5, 518),
(601, 'Combien de dieu trône a l’Olympe ?', 6, 601),
(602, 'Qu’appelle-t-on la canopée ?', 6, 602),
(603, 'Combien y a-t-il de miles marins dans un degré de latitude ?', 6, 603),
(604, 'Qui est le dieu du Soleil dans l\'ancienne Egypte ?', 6, 604),
(605, 'Sur quel continent se trouve la Terre-Adélie ?', 6, 605),
(606, 'Quelle capitale se dresse au confluent du Nil bleu et du Nil blanc ?', 6, 606),
(607, 'Quand a eu lieu le début de la civilisation égyptienne ?', 6, 607),
(608, 'Quand la civilisation grecque est-elle apparue ?', 6, 608),
(609, 'Quand a eu lieu les premiers jeux olympique à Olympie (grèce anthique)?', 6, 609),
(610, 'Quand a été fondé Rome ?', 6, 610),
(611, 'En quelle année a été fondé l\'URSS ?', 6, 611),
(612, 'Que signifie palimpseste ?', 6, 612),
(613, 'Quelle révolutionnaire française est l’auteure de la déclaration des droits de la femme et de la citoyenne ?', 6, 613),
(614, 'Quel état des Etats-Unis a pour capitale Montgomery ?', 6, 614),
(615, 'A quelle race de chat appartient le célèbre chat fictif nommé \'garfield\'', 6, 615),
(616, 'Quelle est la capitale du Sri Lanka ?', 6, 616);

-- --------------------------------------------------------

--
-- Table structure for table `reponse`
--

DROP TABLE IF EXISTS `reponse`;
CREATE TABLE IF NOT EXISTS `reponse` (
  `Reponse_id` int(3) NOT NULL,
  `Reponse_label` varchar(400) DEFAULT NULL,
  `question` int(3) NOT NULL,
  `valid` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`Reponse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `reponse`
--

INSERT INTO `reponse` (`Reponse_id`, `Reponse_label`, `question`, `valid`) VALUES
(101, 'Madride', 101, NULL),
(102, 'Bern', 102, NULL),
(103, 'Tokyo', 103, NULL),
(104, '1945', 104, NULL),
(105, '8 -- 11 -- 3 -- 6', 105, NULL),
(106, '8', 106, NULL),
(107, '1', 107, NULL),
(108, 'ROI', 108, NULL),
(109, '1', 109, NULL),
(110, 'washington', 110, NULL),
(111, 'Rome', 111, NULL),
(112, 'Mexico', 112, NULL),
(113, '12', 113, NULL),
(114, 'Roméo', 114, NULL),
(115, 'do', 115, NULL),
(116, 'Neil Armstrong', 116, NULL),
(117, '5', 117, NULL),
(118, 'Bowser -- warrio -- Waluidgi -- BOO', 118, NULL),
(119, 'Vert et Blanc', 119, NULL),
(201, 'Jean de La Fontaine', 201, NULL),
(202, 'Mont Blanc -- Grandes Jorasses -- Alpes -- Mont Pelvoux --', 202, NULL),
(203, '12', 203, NULL),
(204, 'Victor Hugo -- Jean de la Fontaine -- Charles Beaudelaire -- Gustave Flaubert', 204, NULL),
(205, 'De plancton', 205, NULL),
(206, 'Une planète géante gazeuse -- Une étoile -- Une planète tellurique -- Un satellite à atmosphère dense', 206, NULL),
(207, 'Cosmonaute -- Astronaute -- Taïkonaute -- Spationaute', 207, NULL),
(208, '22 -- 17 -- 28 -- 20', 208, NULL),
(209, '1995', 209, NULL),
(210, 'Mars -- Vénus -- Jupiter -- Saturne', 210, NULL),
(211, '1789 -- 1748 -- 1802 -- 1798', 211, NULL),
(212, '5', 212, NULL),
(213, 'Staline -- Lénine -- Mussolini -- Hitler', 213, NULL),
(214, 'La seconde guerre mondiale', 214, NULL),
(215, 'FAUX', 215, NULL),
(216, 'Posséidons -- Zeus -- Fizz -- Hadès', 216, NULL),
(217, 'La baleine bleu -- Le rorqual -- Le requin baleine -- Le calmar colossal', 217, NULL),
(218, 'Les poilus', 218, NULL),
(301, 'Everest -- Massif Vinson --  Puncak Jaya -- Aconcagua', 301, NULL),
(302, 'La Voie Lactée', 302, NULL),
(303, 'New York -- washington --  Los Angeles -- Chicago', 303, NULL),
(304, '1945 -- 1938 --  1947 -- 1951', 304, NULL),
(305, 'Lumière blanche -- Lumière rouge -- Lumière blue -- Lumière verte', 305, NULL),
(306, 'Le court', 306, NULL),
(307, 'Autriche -- France -- Belgique -- Suisse ', 307, NULL),
(308, 'La Chine', 308, NULL),
(309, '9 -- 10 -- 11 -- 12', 309, NULL),
(310, 'trimaran', 310, NULL),
(311, '300 000 km/s -- 3 000 km/s -- 3 000 0000 m/s --  30 000 m/s', 311, NULL),
(312, '1769 -- 1693 -- 1709 -- 1741', 312, NULL),
(313, '2002 -- 2000 -- 2001 -- 2003', 313, NULL),
(314, 'American Curl -- Bichon frisé -- Teckel -- Shiba Inu', 314, NULL),
(315, 'Non fongible token -- North Frontier Texas -- No French Trouble -- Not Fresh Toast', 315, NULL),
(401, '1998 -- 1993 -- 1999 -- 1997', 401, NULL),
(402, 'Cheval de mer', 402, NULL),
(403, 'Waston -- shakespear -- J.K. Rowling -- Daniel Defoe', 403, NULL),
(404, 'L\'amazone -- Le Nil -- Le Mississippi -- L\'Ob', 404, NULL),
(405, '1 392 684 km -- 3 904 398 km -- 10 143 859 km -- 7 456 298 km', 405, NULL),
(406, 'Une planète géante composée de gaz légers -- Une planète géante exhalant du méthane -- Une planète géante composée de gaz solides -- Une planète géante dont la surface est recouverte d\'une couche d\'hélium et d\'ammoniac', 406, NULL),
(407, 'Une planète dont l\'atmosphère est semblable à celle de la Terre -- Un satellite d\'une planète -- Une planète telluriuqe  -- Une planète anormalement constitué de deux petit noyau', 407, NULL),
(408, 'Une nébuleuse -- Un trou noir -- Une supernova -- Une comète', 408, NULL),
(409, '1989', 409, NULL),
(410, 'Pendragon', 410, NULL),
(411, 'Salzbourg -- Vienne -- Budapest -- Paris', 411, NULL),
(412, '210 millions -- 200 millions -- 175 millions -- 220 millions ', 412, NULL),
(413, 'Istanbul -- Tashkent -- Ekaterinbourg -- Moscou', 413, NULL),
(414, 'Toyota Corolla -- Honda CRV -- Peugeot 208 -- Volkswagen Golf', 414, NULL),
(415, 'Tornade - Danseuse - Fringant - Furie - Comète - Cupidon - Tonnerre - Eclair - Gui', 415, NULL),
(416, 'Athéna -- Aphrodite -- Héra -- Rhéa', 416, NULL),
(417, 'Hadès', 417, NULL),
(501, 'Circus', 501, NULL),
(502, 'Reagan -- Richard Nixon -- Joe Biden -- Bill Clinton', 502, NULL),
(503, 'Volga -- Petchora -- Rhin -- Viatka', 503, NULL),
(504, 'coquillages', 504, NULL),
(505, 'Esmeralda', 505, NULL),
(506, 'Le Machu Picchu au Pérou -- La grande pyramide de Khéops à Gizeh en Egypte -- La statue de Zeus à Olympie en Grèce -- Le Colosse de Rhode en Grèce', 500, NULL),
(507, 'La grande muraille de Chine -- Le temple d\'Artémis à Ephèse -- Le mausolée d\'Halicarnasse en Turquie -- Le Phare d\'Alexandrie en Égypte', 500, NULL),
(508, 'Louis-Napoléon Bonaparte -- Henri II --  Charles IX -- Louis XV', 508, NULL),
(509, '1946 -- 1926 -- 1973 -- 1912', 509, NULL),
(510, '1905 -- 1899 -- 1912 -- 1921', 510, NULL),
(511, 'L\'attent de Sarajevo (Héritier de l\'Empire austro-hongrois)', 511, NULL),
(512, '1916', 512, NULL),
(513, 'Oléron -- Ré -- Noirmoutier -- Île Sainte-Marguerite', 513, NULL),
(514, 'Poussée d\'Archimède', 514, NULL),
(515, 'Chèvre -- Mouton -- Agneau -- Renard', 515, NULL),
(516, 'Sealand -- Luxembourg -- Le vatican -- Saint-Marin', 516, NULL),
(517, 'Héphaïstos -- Arès -- Hermès -- Dionysos', 517, NULL),
(518, 'Hedwige', 518, NULL),
(601, '12 -- 7 -- 9 -- 10', 601, NULL),
(602, 'Le sommet de la forêt amazonienne -- un barrage en Afrique du sud -- la tombe sacrée des Momies -- ', 602, NULL),
(603, '60 -- 45 -- 75 -- 100', 603, NULL),
(604, 'Râ -- Thot -- Anubïs -- Solâna', 604, NULL),
(605, 'En Antarctique -- Océanie -- Asie -- Afrique', 605, NULL),
(606, 'Karthoum -- Le Caire -- Djouba -- Pretoria', 606, NULL),
(607, '3000 avant JC -- 5000 avant JC -- 1300 avant JC -- 7500 avant JC', 607, NULL),
(608, '-2000 -- -1000 -- -555 -- -133', 608, NULL),
(609, '775 avant JC -- 880 avant JC -- 405 avant JC -- 222 avant JC', 609, NULL),
(610, '750 avant JC -- 1000 avant JC -- 2000 avant JC -- 550 avant JC', 610, NULL),
(611, '1922 -- 1920 -- 1924 -- 1926', 611, NULL),
(612, 'Manuscrit dont on a fait disparaître l’écriture pour y écrire un autre texte -- Raisonnement par lequel on démontre la vérité d’une proposition en prouvant l’impossibilité de la proposition contraire -- Farceur, personnage qui manque de sérieux -- Un croisé entre un pingouin et un manchot ', 612, NULL),
(613, 'Olympe de Gouges -- Marianne -- Ariette de Bote -- Corinne', 613, NULL),
(614, 'Alabama -- Géorgie -- Louisiane -- Californie', 614, NULL),
(615, 'Exotic Shortair -- British shorthair -- Ragdoll -- Scottish fold', 615, NULL),
(616, 'Sri Jayawardenapura Kotte -- Bandar Seri Begawan -- Mbabane  -- Reykjavik ', 616, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
CREATE TABLE IF NOT EXISTS `role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `ROLE_USER` tinyint(1) NOT NULL DEFAULT '1',
  `ROLE_ADMIN` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`role_id`, `ROLE_USER`, `ROLE_ADMIN`) VALUES
(1, 0, 1),
(2, 1, 0),
(3, 1, 0),
(4, 1, 0),
(5, 1, 0),
(6, 1, 0),
(7, 1, 0),
(9, 1, 0),
(10, 1, 0),
(11, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `password` varchar(96) CHARACTER SET ascii NOT NULL,
  `email` text CHARACTER SET ascii NOT NULL,
  `role` int(11) DEFAULT NULL,
  `firstName` varchar(10) CHARACTER SET ascii NOT NULL,
  `lastName` varchar(10) CHARACTER SET ascii NOT NULL,
  `CrearedAt` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `email`, `role`, `firstName`, `lastName`, `CrearedAt`) VALUES
(1, 'admin', '$argon2i$v=19$m=65536,t=4,p=1$RGN3d2prVFRXSWZOOVQ0dA$UDjNL8UbSIzoF3wlxQdyDJ15TiW3sv/JQzvtWIvweeU', 'ad@min.com', 1, 'admin', 'admin', '2022-01-06 22:54:07'),
(4, 'selim', '$argon2i$v=19$m=65536,t=4,p=1$cnNEcjMySlp2bGZHdTNJNA$3KBqvtPaCrkcAXjS9g7vUiWX/0bpasFe2vbkFBOhH3Y', 'szouache17@gmail.com', 4, 'selim', 'Z', '2022-01-04 18:29:58'),
(6, 'antoine', '$argon2i$v=19$m=65536,t=4,p=1$dEQ5cTZadlhlZmNhMVhkVw$y6JoBia6NtUa1D1aSMjYD1rySm5r8tc2Cckx8BtOTCg', 'szouache17@gmail.com', 6, 'antoine', 'B', '2022-01-06 17:02:36'),
(7, 'julian', '$argon2i$v=19$m=65536,t=4,p=1$OWc4SUg5ZGxmUHVyeXpRMw$GRrozs0VGGlihrhZ87Gq++q07GplPMDxjT+ALoPLm0U', 'szouache17@gmail.com', 7, 'julian', 'H', '2022-01-06 17:03:03'),
(9, 'test4', '$argon2i$v=19$m=65536,t=4,p=1$Z3pYMTFmQWtGZ2tYbFdPZg$kDdb4ACnWG6ijY/PrSswudpP3J1/p9bRP50Z/aa2KBs', 't4@gmail.com', 9, 'test4', 'T4', '2022-01-07 10:34:14'),
(10, 'test5', '$argon2i$v=19$m=65536,t=4,p=1$RHFIdFk0cFViTXZra2VuMA$X1rpisbHxSt+R4jDyUOrJmm1oWnfl+h/i2A0C8Hn9VU', 't5@gmail.com', 10, 'test5', 'T5', '2022-01-07 10:34:54'),
(11, 'test6', '$argon2i$v=19$m=65536,t=4,p=1$aGF2NmVRZW5nSVMzLjhlYg$DRTrge7oPMpPNC4hccyVADrlByTp2uj9tutrJDq7mIo', 't6@gmail.com', 11, 'test6', 'T6', '2022-01-07 10:35:17');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
