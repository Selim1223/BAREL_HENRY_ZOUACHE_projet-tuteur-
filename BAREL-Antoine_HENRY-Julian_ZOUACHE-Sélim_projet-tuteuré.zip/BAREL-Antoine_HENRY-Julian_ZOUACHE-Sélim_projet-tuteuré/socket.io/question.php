<?php

use Database\DBConnection;

$bdd = DBConnection::getConnection();
    
    $lvl = $_POST['val'];
    var_dump($lvl);
    //Compte le nombre de question du Niveau choisi
    $stmt = $bdd->prepare('SELECT COUNT(*) FROM question WHERE Niveau = :lvl');
    $stmt->bindParam('lvl', $lvl, PDO::PARAM_STR);
    if ($stmt->execute()) {
        //var_dump($stmt->fetchAll(PDO::FETCH_ASSOC));
            $nb_question .= '<div>' . $stmt->fetch(PDO::FETCH_ASSOC) .'<div>';
    }

    $quesiton = random_int(1,$nb_question['COUNT(*)']);

    $SelectQuestion = $lvl*100 + $quesiton;

    $stmt = $bdd->prepare('SELECT Question_id, Question_label,Reponse_label FROM question INNER JOIN reponse ON question.Question_id = reponse.Reponse_id WHERE Question_id <= :nb ORDER BY Question_id Desc
    LIMIT 0,1');
    $stmt->bindParam('nb', $SelectQuestion, PDO::PARAM_STR);
    $InfoQuestion = '';
    if ($stmt->execute()) {
        //var_dump($stmt->fetchAll(PDO::FETCH_ASSOC));
            $InfoQuestion = $stmt->fetch(PDO::FETCH_ASSOC);
    }

    echo $InfoQuestion;

    // $Reponses = explode(' -- ', $InfoQuestion['Reponse_label']);

    // $NB_reponse = count($Reponses);

    // $_SESSION['Reponse_juste'] = $Reponses[0];

    // var_dump($_SESSION['Reponse_juste']);
    // shuffle($Reponses);

    