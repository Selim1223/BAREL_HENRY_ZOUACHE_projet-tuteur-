const { on } = require('events');
const { emit } = require('process');

const app = require('express')();
const http = require('http').Server(app);
const io = require("socket.io")(http);
const port = process.env.PORT || 3000;
var mysql = require('mysql');
  var connection = mysql.createConnection({
      host: 'localhost',
      user: 'root',
      password: '',
      database: 'test'
  });

var nb_joueur = 0;
var joueurs = [];
const Rooms = [];


app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

// io.use((socket, next) => {
//   const username = socket.handshake.auth.username;
//   socket.username = username;
//   next();
// });

io.on('connection', (socket) => {

  socket.on('users', user => {

    socket.user = user;

    user.socketId = socket.id

    let joueur = {id: user.socketId, username: user.username, host: user.role};

    joueurs[nb_joueur] = joueur;

    //join_game

    
    //const room = {id: user.roomId, nb_players: 0, players: []};

    // console.log('bou '+ socket.Rooms)
    // if (!socket.Rooms.includes(room)) {
    //   console.log('nouvelle room !')
    //   room.nb_players++;
    //   players.push(user.username);
    //   Rooms.room.push(room)
    // }
    // else{
    //   socket.Rooms.forEach(room => {
    //     console.log('room existante')
    //     if (room.id = user.roomId) {
    //       room.nb_players++;
    //       players.push(user.username);
    //       console.log('nb  joueur room : ' + room.nb_players)
    //     }
    //   });
    // }
    

    socket.join(user.roomId)

    if (nb_joueur == 0) {
      socket.join();
    }
    console.log('id_room : ' + user.roomId)

    //socket.room = user.roomId;

    // Rooms[user.roomId]++;

    // console.log('room ' + Rooms[user.roomId])

    
    console.log('Bienvenue à '+ user.username + " | " + joueurs[nb_joueur].id)
    nb_joueur++;
    console.log(user.nb)

    if (nb_joueur == user.nb) {
      // startGame()
      io.to(user.roomId).emit('Alljoueur', joueurs);
      io.to(user.roomId).emit('affiche lvl');
      console.log('La partie commence avec : ')
      joueurs.forEach(element => {
        console.log(element)
      });

      
    }

    socket.on('affiche question',  function(val){
    
      console.log('user : ' + user.username);
      //let val = 6;
      connection.query(`SELECT COUNT(*) FROM question WHERE Niveau = ?`, val, function (err,rows, fields) {
        if (err) {
        console.log('error : ' + err.code)
        }
        else if (rows.length === 1) {
          console.log(rows[0])
          let random_nb = Math.random() * (rows[0]['COUNT(*)'])+1;
          let selectQuestion = val*100+random_nb;
      
          connection.query(`SELECT Question_id, Question_label,Reponse_label FROM question INNER JOIN reponse ON question.Question_id = reponse.Reponse_id WHERE Question_id <= ? ORDER BY Question_id Desc
          LIMIT 0,1`, selectQuestion, function (err,rows, fields) {
            if (err) {
              console.log('error : ' + err.code)
            }
            else if (rows.length === 1) {
              console.log('question : ' + rows[0].Question_label);
              
              console.log('room : ' + user.roomId)

              
              let Rep =  rows[0].Reponse_label.split(' -- ');

              socket.emit('ResultT', Rep[0]);
              socket.to(user.roomId).emit('ResultT', Rep[0]);
              
              Rep.sort(()=> Math.random() - 0.5);
              //socket.emit('reponse', Rep[0])

              socket.emit('Info', rows[0], Rep, val);
              socket.to(user.roomId).emit('Info', rows[0],Rep,val);
              
            }
          })
        }
      })      
  
    })

    socket.on('verifRep', function (reponse) {
      socket.emit('Verif', reponse);
      socket.to(user.roomId).emit('Verif', reponse);
    })

    // socket.on('reponse', function (reponse) {

    //   console.log('je passe par là ;o')

      
    //   socket.emit('Reponse', Rep);
    // })

    socket.on('disconnect', function () {

      socket.emit('disconnected');
      console.log(user.username + ' est partie !')
      nb_joueur--;
      Rooms[user.roomId]--;
    });
  });


 
  

  // socket.on('disconnect', function () {

  //   socket.emit('disconnected');
  //   console.log(socket.id +', user disconnected')
  //   nb_joueur--;
  // });

});


http.listen(port, () => {
  console.log(`Socket.IO server running at http://localhost:${port}/`);
});

