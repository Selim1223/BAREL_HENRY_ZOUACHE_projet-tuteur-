const player = {
    host:false,
    roomId:null,
    username:"",
    socketId: "",
    couleur: "",
    win: false
};

const socket = io();