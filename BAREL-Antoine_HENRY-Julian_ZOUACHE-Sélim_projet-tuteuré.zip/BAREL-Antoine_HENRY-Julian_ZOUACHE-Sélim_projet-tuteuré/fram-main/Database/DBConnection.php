<?php

namespace Database;

use PDO;

use function PHPSTORM_META\map;

class DBConnection
{   

        public function __construct( )
        {
            
        }

    public static function getConnection()
    {
        try {
            $connection = new PDO('mysql:host=127.0.0.1;dbname=test;charset=utf8', 'root', '');
        } catch (\PDOException $e) {
            echo "Erreur !: " . $e->getMessage() . "<br/>";
            die();
        }

        return $connection;
    }


        function registerUser(array $data): bool
    {
        $connection = DBConnection::getConnection(); 

        $sql = 'INSERT INTO 
            users(`username`, `password`,`email`, `firstName`, `lastName`)
            VALUES
                (:username, :password, :email , :first_name, :last_name);

            INSERT INTO role(`role_id`) SELECT `user_id` FROM `users` WHERE `user_id` = (
            select `user_id` from `users` order by `user_id` DESC LIMIT 1
            );

            UPDATE users SET role = `user_id`;
        ';

        $password = password_hash($data['password'], PASSWORD_ARGON2I);

        $stmt = $connection->prepare($sql);
        $stmt->bindParam('first_name', $data['first_name'], PDO::PARAM_STR);
        $stmt->bindParam('password', $password, PDO::PARAM_STR);
        $stmt->bindParam('username', $data['username'], PDO::PARAM_STR);
        $stmt->bindParam('last_name', $data['last_name'], PDO::PARAM_STR);
        $stmt->bindParam('email', $data['email'], PDO::PARAM_STR);

        return $stmt->execute();
    }

    
    function loginUser(array $data): int
    {
        $connection = DBConnection::getConnection(); 

        $sql = 'SELECT COUNT * FROM users
            WHERE `username` = :username
            AND `password` = :password    
        ';

        $stmt = $connection->prepare($sql);
        $stmt->bindParam('username', $data['username'], PDO::PARAM_STR);
        $stmt->bindParam('password', $data['password'], PDO::PARAM_STR);
        return $stmt->execute();
    }


        function getUser($username): array
    {
        $connection = DBConnection::getConnection();
        $stmt = $connection->prepare('SELECT * from `users` where username=:username');
        $stmt->bindParam('username', $username, PDO::PARAM_STR);
        if ($stmt->execute()) {
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }

        return [];

    }

        function checkUserCredentials(string $username, string $password): bool
    {
        $connection = DBConnection::getConnection();
        $stmt = $connection->prepare('SELECT `password` from `users` WHERE `username`=:username');
        $stmt->bindParam('username', $username, PDO::PARAM_STR);

        if ($stmt->execute()) {
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if (isset($result['password']) && password_verify($password, $result['password'])) {
                return true;
            }
            return false;
        }

        return false;

    }

    function userExist(string $username): bool
    {
    $connection = DBConnection::getConnection();
    $stmt = $connection->prepare('SELECT COUNT(*) as nb from `users` WHERE `username`=:username');
    $stmt->bindParam('username', $username, PDO::PARAM_STR);

    if ($stmt->execute()) {
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['nb'] > 0;
    }

    return false;
    }


    function Getquestion(int $id): array
    {
    $connection = DBConnection::getConnection();
    $stmt = $connection->prepare('SELECT Question_label, Reponse_label from question,reponse WHERE `Question_id`= :id');
    $stmt->bindParam('id', $id, PDO::PARAM_STR);

    if ($stmt->execute()) {
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    return [];
    }
    
}