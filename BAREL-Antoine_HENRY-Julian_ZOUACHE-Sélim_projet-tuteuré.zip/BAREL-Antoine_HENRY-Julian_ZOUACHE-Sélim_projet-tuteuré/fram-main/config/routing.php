<?php

use App\Controller\Admin\PageAdmin;
use App\Controller\Homepage;
use App\Controller\Page;
use App\Controller\Partie\Accueil;
use App\Controller\question\DeleteQuestion;
use App\Controller\User\GestionUsers;
use App\Controller\question\ModifyQuestion;
use App\Controller\question\GestionQuestions;
use App\Controller\User\DeleteUser;
use App\Controller\User\ModifyUser;
use App\Controller\User\Register;
use App\Controller\User\SignIn;
use App\Controller\Partie\AfficheQuestion;
use App\Controller\Partie\Game;
use App\Controller\Admin\Invitation;

use Framework\Routing\Route;    

return [
    new Route('GET', '/', Homepage::class),
    new Route('GET', '/index/question/affiche', GestionQuestions::class),
    //new Route('GET', '/index/question/deletequestion/id={id}', questionadmin::class),
    new Route(['GET', 'POST'], '/index/question/modifyquestion/{id}', ModifyQuestion::class),
    new Route(['GET', 'POST'], '/index/question/deletequestion/{id}', DeleteQuestion::class),
    new Route('GET', '/index/page', Page::class),
    new Route(['GET', 'POST'], '/index/user/login', SignIn::class),
    new Route(['GET', 'POST'], '/index/user/register', Register::class),
    new Route(['GET', 'POST'], '/index/user/affiche', GestionUsers::class),
    new Route(['GET', 'POST'], '/index/user/modifyuser/{id}', ModifyUser::class),
    new Route(['GET', 'POST'], '/index/user/deleteuser/{id}', DeleteUser::class),
    new Route(['GET', 'POST'], '/index/admin/page', PageAdmin::class),
    new Route(['GET', 'POST'], '/index/jeu/accueil', Accueil::class),
    new Route(['GET', 'POST'], '/index/jeu/game', Game::class),
    new Route(['GET', 'POST'], '/index/jeu/game/Question/{lvl}', AfficheQuestion::class),
    new Route(['GET', 'POST'], '/index/admin/invitation', Invitation::class), 

];
