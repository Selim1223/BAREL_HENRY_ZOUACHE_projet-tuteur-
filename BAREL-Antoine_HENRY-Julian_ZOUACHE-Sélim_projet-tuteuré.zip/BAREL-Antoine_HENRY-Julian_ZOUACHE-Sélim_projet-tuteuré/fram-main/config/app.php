<?php

return [
    'APP_ENV'=> 'prod',
];
