<?php

namespace App\Controller\User;

use App\Controller\Admin\PassAdmin;
use Database\DBConnection;
use Framework\Controller\AbstractController;
use PDO;

class ModifyUser extends AbstractController
{

    public function __invoke(int $id): string
    {
        $PassAdmin = new PassAdmin;
        $PassAdmin->Control();
        
        if ($this->isPost()) {

            $firstName = $_POST['firstName'];
            $lastName = $_POST['lastName'];
            $email = $_POST['email'];

            // var_dump($_POST['ROLE_USER+1']);
            // var_dump($_POST['ROLE_ADMIN+1']);


            if (isset($_POST['ROLE_USER+1'])) {
                $role_User = '1';
            }
            else $role_User = '0';

            if (isset($_POST['ROLE_ADMIN+1'])) {
                $role_Admin = '1';
            }
            else $role_Admin = '0';

        //    var_dump($role_User);
        //    var_dump($role_Admin);
           

            if (!empty($firstName) && !empty($lastName) && !empty($email)) {

                $bdd = DBConnection::getConnection();

                $modify = $bdd->prepare(
                    'UPDATE users SET firstName=? WHERE user_id =?;
                     UPDATE users SET lastName=? WHERE user_id =?;
                     UPDATE users SET email=? WHERE user_id =?;
                     UPDATE `role` SET ROLE_USER=? WHERE role_id =?;
                     UPDATE `role` SET ROLE_ADMIN=? WHERE role_id =?;
                     ');
                $modify->execute([$firstName, $id, $lastName, $id, $email, $id, $role_User, $id, $role_Admin, $id]); 
                    
                
                $this->redirect('/index/user/affiche');
            }
            else{
                echo '<script type="text/javascript">window.alert("Vous devez remplir tous les champs..");</script>';

            }
            
        }

        $connection = DBConnection::getConnection();

        $stmt = $connection->prepare('SELECT username,firstName, lastName, email,role from users WHERE `user_id`= :id');
        $stmt->bindParam('id', $id, PDO::PARAM_STR);
        $stmt2 = $connection->prepare('SELECT ROLE_USER, ROLE_ADMIN from `role` WHERE `role_id` = :id');
        $stmt2->bindParam('id', $id, PDO::PARAM_STR);

        
        if ($stmt->execute() && $stmt2->execute()) {
            //var_dump($stmt->fetchAll(PDO::FETCH_ASSOC));
             $InfoUser = $stmt->fetch(PDO::FETCH_ASSOC);
             $role = $stmt2->fetch(PDO::FETCH_ASSOC);
        }

        //var_dump($role);

        //changer stockRole -> le ciblé sur l'ID
        

        return $this->render('user/modifyUser.html.twig', [
            'username' => $InfoUser['username'],
            'firstName' => $InfoUser['firstName'],
            'lastName' => $InfoUser['lastName'],
            'email' => $InfoUser['email'],
            'roles' => $role,
            'id' => $id
        ]);
    }
}
