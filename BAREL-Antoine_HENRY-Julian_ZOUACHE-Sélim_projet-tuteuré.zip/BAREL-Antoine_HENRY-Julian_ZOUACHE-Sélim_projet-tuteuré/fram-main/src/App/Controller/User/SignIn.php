<?php

namespace App\Controller\User;

use Framework\Controller\AbstractController;
use Database\DBConnection;
use PDO;

session_start();

class SignIn extends AbstractController
{ 
  
  public function __invoke()
  {
    if (isset($_SESSION['username'])) {
      session_destroy();
    }

    $username = "";
    $MDP = "";

   
    if ($this->isPost()) {
      // vérify
      // send to Model -> BDD
      // create the user inside the database

    $username = $_POST['username'];
    
    $MDP = $_POST['MDP'];

    $connection = DBConnection::getConnection();
    $stmt = $connection->prepare('SELECT `password`,`user_id` from `users` WHERE `username`=:username');
    $stmt->bindParam('username', $username, PDO::PARAM_STR);

    if ($stmt->execute()) {
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if (isset($result['password']) && password_verify($MDP, $result['password'])) {
            $trouve = true;
        }else $trouve = false;

    }
      
    if($trouve == true){

      $connection = DBConnection::getConnection();
      $stmt = $connection->prepare('SELECT `ROLE_ADMIN` from `role` WHERE `role_id` = :id');
      $stmt->bindParam('id', $result['user_id'], PDO::PARAM_STR);

      if ($stmt->execute()) {
          $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    }


      var_dump($admin);

      if ($admin['ROLE_ADMIN']) {
        $_SESSION['username'] = $username;
        $this->redirect('/index/admin/page');
      }else{
        $_SESSION['username'] = $username;
        $_SESSION['id'] = $result['user_id'];
        $this->redirect('/index/jeu/accueil');
      }
      }
      else{
        return $this->render(
            'user/login.html.twig',
            [
              'username' => $_POST['username'],
              'error' => true        
            ]);

      }

    }

    return $this->render(
      'user/login.html.twig',
      [
        'username' => $username,
        'error' => false
      ]);
  }

}