<?php

namespace App\Controller\User;

use App\Entity\User;
use Framework\Controller\AbstractController;

session_start();

class Register extends AbstractController
{ 
  
  public function __invoke()
  {

    if (isset($_SESSION['username'])) {
      session_destroy();
    }

    $username = "";
    $firstName = "";
    $lastName = "";
    $email = "";
    $MDP = "";

   
    if ($this->isPost()) {
      // vérify
      // send to Model -> BDD
      // create the user inside the database

  
      $user = new User($_POST['username'],$_POST['MDP'],$_POST['firstName'],$_POST['lastName'],$_POST['email']);


      $result = $user->verify($_POST['username'],$_POST['MDP'],$_POST['MDPV'],$_POST['firstName'],$_POST['lastName'],$_POST['email']);
      
      $errors = $result[0];
      $correct = $result[1];


    //  var_dump($errors);

      if (empty($errors)) {
        // SESSION ?
        $_SESSION['username'] = $_POST['username'];
        $this->redirect('/index/jeu/accueil');
      }else{

        foreach ($correct as $el => $val) {
          switch($el){
            case 'username':
              $username = $val;
              break;
            case 'firstName':
              $firstName = $val;
              break;
            case 'lastName':
              $lastName = $val;
              break;
            case 'email':
              $email = $val;
              break;
          }
        }

        return $this->render(
          'user/register.html.twig',
          [
            'errors' => $errors,
            'username' => $username,
            'firstName' => $firstName,
            'lastName' => $lastName,
            'email' => $email,
           
          ]);

      }
      
    }

    return $this->render(
      'user/register.html.twig',
      [
        'username' => $username,
        'firstName' => $firstName,
        'lastName' => $lastName,
        'email' => $email,
       
      ]);
  } 
 }