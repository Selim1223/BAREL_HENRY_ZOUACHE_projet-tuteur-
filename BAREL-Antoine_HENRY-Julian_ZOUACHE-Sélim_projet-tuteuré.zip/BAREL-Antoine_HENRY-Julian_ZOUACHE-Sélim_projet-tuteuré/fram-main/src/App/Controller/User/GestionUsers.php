<?php

namespace App\Controller\User;

use App\Controller\Admin\PassAdmin;
use Database\DBConnection;
use Framework\Controller\AbstractController;
use PDO;


class GestionUsers extends AbstractController
{
    public function __invoke()
    {

        $PassAdmin = new PassAdmin;
        $PassAdmin->Control();
        
        $connection = DBConnection::getConnection();

        $stmt = $connection->prepare('SELECT * from users');
        $stmt2 = $connection->prepare('SELECT * from role');

        if ($stmt->execute() && $stmt2->execute()) {
             $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
             $role = $stmt2->fetchAll(PDO::FETCH_ASSOC);
        }


        $stockROle = [];

        foreach ($role as $key => $value) {
          foreach ($value as $attr => $el) {
            switch ($attr) {
              case 'ROLE_USER':
                  if ($el == '1') {
                    $stockROle[$key][]= 'ROLE_USER';
                  }
                break;
                case 'ROLE_ADMIN':
                  if ($el == '1') {
                    $stockROle[$key][]= 'ROLE_ADMIN';
                  }
                break;
                // add autre role
            }
          }
        }

        foreach ($users as $user => $value) {
          foreach ($value as $key => $el) {

          }
        }

        return $this->render(
            'User/gestionUsers.html.twig',
            [
              'users' => $users,
              'roles' => $stockROle
            ]);

    }
}
