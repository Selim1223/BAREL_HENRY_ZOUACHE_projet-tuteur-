<?php

namespace App\Controller\User;

use App\Controller\Admin\PassAdmin;
use Database\DBConnection;
use Framework\Controller\AbstractController;
use PDO;

class DeleteUser extends AbstractController
{
    public function __invoke(int $id)
    {
        $PassAdmin = new PassAdmin;
        $PassAdmin->Control();

        $bdd = DBConnection::getConnection();

        $delete = $bdd->prepare(
            'DELETE FROM users WHERE user_id = :id;
            DELETE FROM `role` WHERE role_id = :id;
            ');
        $delete->execute(array(':id' => $id));

        $this->redirect('/index/user/affiche');
    }
}
