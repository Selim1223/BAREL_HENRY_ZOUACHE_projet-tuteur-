<?php

namespace App\Controller\Admin;

use Database\DBConnection;
use Framework\Controller\AbstractController;
use PDO;

class Invitation extends AbstractController
{
    public function __invoke()
    {

        try {
            $id=random_int(100000, 999999);
            $nb = 0;
            $connection = new PDO('mysql:host=127.0.0.1;dbname=test;charset=utf8', 'root', '');
            $req = $connection->prepare('SELECT email,username FROM users WHERE username = :username');
            for($i = 1; $i <= 6; $i++){
                if (isset($_POST['couleur' . $i]) AND isset($_POST['username' . $i])) {
                        $nb++;
                    }
            }
            $lastNb = $nb+1;
            for ($i = 1; $i <= 6; $i++) {
                if (isset($_POST['couleur' . $i]) AND isset($_POST['username' . $i])) {
                $req->execute(array(':username' =>  $_POST['username' . $i]));
                    echo "Joueur " . $i . ": " . $_POST['username' . $i] . " | Couleur : " . $_POST['couleur' . $i] . '<br>';
                    while ($tab = $req->fetch()) {
        
                        //envoie mail
                        $mail = $tab["email"];
                        $objet = "Invitation pour un Quizz";
                        $message = "Votre ami vous a envoyez une invation pour lancer une partie de quizz. Cliquez sur lien pour continuer : http://localhost:3000/?username=". $tab["username"] ."&color=" . $_POST['couleur' . $i] ."&nb=".$lastNb."&id=".$id."";
        
                         mail($mail, $objet, $message);
                    }
                }
            }
            // echo "mail envoyé";
        } catch (\Throwable $e) {
            echo 'Connexion à la base de données impossible. Vérifier que les identifiants existent et
            que la base de données aussi !';
        }
        ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Document</title>
    <link rel="stylesheet" href="/assets/css/invitation.css" />
    <script src="/scripts/invitation.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>


<body>
    <nav>
        <h1>Invite tes amis !</h1>
    </nav>

    <form action="" method="POST" autocomplete="off">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Utilisateur</th>
                    <th scope="col">Couleur</th>
                    <th scope="col">Envoie</th>
                </tr>
            </thead>

            <tbody>
                <?php for ($i = 1; $i <= 6; $i++) { ?>
                <tr>
                    <th scope="row"><?php echo $i ?></th>

                    <td>
                        <input type="text" name="<?="username" . $i ?>" id="<?="user" . $i ?>" list="languages"
                            value="<?=$_POST['username' . $i] ?? ' ' ?>">
                        <datalist id="languages">
                            <?php
                                        $select = $connection->query("SELECT * FROM users");
                                        while ($row = $select->fetch()) { ?>
                            <option value="<?php echo $row['username'] ?>"></option>
                            <?php } ?>
                        </datalist>
                    </td>
                    <td>
                        <select name="couleur<?= $i ?>" id="selectID<?= $i ?>" onchange="getSelectValue(this.value)">
                            <option selected disabled hidden value="">Couleur</option>
                            <option class="red" id="red" value="Rouge">Rouge</option>
                            <option class="yellow" value="Jaune">Jaune</option>
                            <option class="green" value="Vert">Vert</option>
                            <option class="orange" value="Orange">Orange</option>
                            <option class="pink" value="Rose">Rose</option>
                            <option class="cyan" value="Cyan">Cyan</option>
                        </select>
                    </td>
                    <td>
                        <button type="submit" name="envoyer">envoyer</button>
                    </td>
                    <td>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </form>
    <button class="btn btn-success" style="margin-left:42%;" onclick="window.location.href = 'http://localhost:3000/?username=admin&nb=<?php echo $lastNb ?>&id=<?php echo $id ?>'">Lancer une partie !</button>
</body>

</html>
<?php
            
    }
}