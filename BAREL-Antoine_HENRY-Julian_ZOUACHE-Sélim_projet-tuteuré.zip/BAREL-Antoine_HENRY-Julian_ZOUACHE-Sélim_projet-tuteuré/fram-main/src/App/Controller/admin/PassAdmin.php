<?php

namespace App\Controller\Admin;

use Database\DBConnection;
use Framework\Controller\AbstractController;
use PDO;
session_start();

class PassAdmin extends AbstractController
{
    public function Control()
    {
        if (isset($_SESSION['username'])) {

            $connection = DBConnection::getConnection();
            $stmt = $connection->prepare('SELECT `user_id` from `users` WHERE `username` = :username');
            $stmt->bindParam('username', $_SESSION['username'], PDO::PARAM_STR);

            if ($stmt->execute()) {
                $id = $stmt->fetch(PDO::FETCH_ASSOC);
            }
            
            $stmt = $connection->prepare('SELECT `ROLE_ADMIN` from `role` WHERE `role_id` = :id');
            $stmt->bindParam('id', $id['user_id'], PDO::PARAM_STR);

            if ($stmt->execute()) {
                $admin = $stmt->fetch(PDO::FETCH_ASSOC);
            }

            if (!$admin['ROLE_ADMIN']) {
                return $this->redirect('/index/jeu/accueil');
          }
        }
        else {
            return $this->redirect('/index/user/login');
        }
        
    }
}
