<?php

namespace App\Controller\Admin;

use Database\DBConnection;
use Framework\Controller\AbstractController;
use PDO;

class PageAdmin extends AbstractController
{
    public function __invoke()
    {

        $PassAdmin = new PassAdmin;
        $PassAdmin->Control();
        
        // if(!isset($_SESSION["username"])){
        //     header("location: /PageJeu.php");
        //     exit;
        // }

            $connection = DBConnection::getConnection();
            $stmt = $connection->prepare('SELECT COUNT(*) as totalQuestion FROM question');
            //$result = $stmt->fetch();

            if ($stmt->execute()) {
                //var_dump($stmt->fetchAll(PDO::FETCH_ASSOC));
                 $nb_question = $stmt->fetch(PDO::FETCH_ASSOC);
                 $stmt->closeCursor();
            }
        
            $req = $connection->prepare('SELECT COUNT(*) as totalUsers FROM users');
            if ($req->execute()) {
                //var_dump($stmt->fetchAll(PDO::FETCH_ASSOC));
                 $nb_user = $req->fetch(PDO::FETCH_ASSOC);
                 $req->closeCursor();
            }            
    
            return $this->render('admin/InfoAdmin.html.twig', [
                'totalQuestion' => $nb_question['totalQuestion'],
                'totalUsers' => $nb_user['totalUsers']
            ]);
    }
}
