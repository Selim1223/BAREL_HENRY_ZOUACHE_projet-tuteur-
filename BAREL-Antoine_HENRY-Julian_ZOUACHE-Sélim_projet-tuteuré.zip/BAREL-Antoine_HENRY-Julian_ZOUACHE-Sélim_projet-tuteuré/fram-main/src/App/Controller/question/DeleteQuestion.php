<?php

namespace App\Controller\question;

use App\Controller\Admin\PassAdmin;
use Database\DBConnection;
use Framework\Controller\AbstractController;
use PDO;

class DeleteQuestion extends AbstractController
{
    public function __invoke(int $id)
    {
        $PassAdmin = new PassAdmin;
        $PassAdmin->Control();

        $bdd = DBConnection::getConnection();

        $delete = $bdd->prepare('DELETE FROM question WHERE Question_id = :id;
        DELETE FROM reponse WHERE Reponse_id= :id;');
        $delete->execute(array(':id' => $id));


        $this->redirect('/index/question/affiche');
    }
}
