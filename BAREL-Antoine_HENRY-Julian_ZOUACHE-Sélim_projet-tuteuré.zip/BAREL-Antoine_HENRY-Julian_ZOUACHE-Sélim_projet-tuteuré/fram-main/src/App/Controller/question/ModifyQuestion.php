<?php

namespace App\Controller\question;

use App\Controller\Admin\PassAdmin;
use Database\DBConnection;
use Framework\Controller\AbstractController;
use PDO;

class ModifyQuestion extends AbstractController
{
    const maxReponse=4;
    const minReponse=1;

    public function __invoke(int $id): string
    {
        $PassAdmin = new PassAdmin;
        $PassAdmin->Control();

        if ($this->isPost()) {

            $question = $_POST['question'];
            $nb_question = $_POST['nb_reponse'];
            $isValide = false;
            $reponse = '';

            switch ($nb_question) {
                case '4':
                    
                    if ( $_POST['reponse1'] != '' && $_POST['reponse2'] != '' && $_POST['reponse3'] != '' && $_POST['reponse4'] != '') {
                        $isValide = true;

                        for ($i=1; $i <= $nb_question; $i++) {
                            $i = strval($i);

                            var_dump($i);
                            if ($i != '4') {
                                $reponse = $reponse . $_POST['reponse'.$i].' -- ';
                                
                            }
                            else $reponse = $reponse . $_POST['reponse'.$i];
                        }
                    }

                    break;
                
                default:
                    
                    if (isset($_POST['reponse1']) || $_POST['reponse1'] != '') {
                        $isValide = true;
                        $reponse = $_POST['reponse1'];
                    }
                    break;
            }
            
            if (!empty($question) && $isValide == true) {

                
                $bdd = DBConnection::getConnection();

                $modify = $bdd->prepare(
                    'UPDATE question SET Question_label=? WHERE question.Question_id =?;
                     UPDATE reponse SET Reponse_label=? WHERE reponse.question =?;');
                $modify->execute([$question, $id, $reponse, $id]);   

                $this->redirect('/index/question/affiche');
            }
            else{
                echo '<script type="text/javascript">window.alert("Vous devez remplir tous les champs..");</script>';

            }
            
        }

        $connection = DBConnection::getConnection();

        $stmt = $connection->prepare('SELECT Question_label, Reponse_label, Niveau from question INNER JOIN reponse ON question.Question_id = reponse.Reponse_id WHERE `Question_id`= :id');
        $stmt->bindParam('id', $id, PDO::PARAM_STR);

        if ($stmt->execute()) {
            //var_dump($stmt->fetchAll(PDO::FETCH_ASSOC));
             $InfoQuestion = $stmt->fetch(PDO::FETCH_ASSOC);
        }

        $Reponses = explode(' -- ', $InfoQuestion['Reponse_label']);

        $NB_reponse = count($Reponses);
        

        return $this->render('questions/modifyQuestion.html.twig', [
            'question' => $InfoQuestion['Question_label'],
            'reponses' => $Reponses,
            'NB_reponse' => $NB_reponse,
            'Niveau' =>$InfoQuestion['Niveau'],
            'id' => $id
        ]);
    }
}
