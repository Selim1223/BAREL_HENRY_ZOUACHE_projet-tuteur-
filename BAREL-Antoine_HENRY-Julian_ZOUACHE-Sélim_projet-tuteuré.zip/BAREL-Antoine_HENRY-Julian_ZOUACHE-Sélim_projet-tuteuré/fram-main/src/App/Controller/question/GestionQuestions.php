<?php

namespace App\Controller\question;

use App\Controller\Admin\PassAdmin;
use Database\DBConnection;
use Framework\Controller\AbstractController;
use PDO;


class GestionQuestions extends AbstractController
{
    public function __invoke()
    {
        $PassAdmin = new PassAdmin;
        $PassAdmin->Control();
        
        $connection = DBConnection::getConnection();

        $stmt = $connection->prepare('SELECT * from question,reponse WHERE question.Question_id = reponse.Reponse_id');

        if ($stmt->execute()) {
            //var_dump($stmt->fetchAll(PDO::FETCH_ASSOC));
             $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        //var_dump($questions);

        //$tab = json_decode(json_encode($questions), true);

        return $this->render(
            'questions/gestionQuestions.html.twig',
            [
              'questions' => $questions
            ]);

        // echo count($questions);

        // while($res){
            
        // }

    }
}
