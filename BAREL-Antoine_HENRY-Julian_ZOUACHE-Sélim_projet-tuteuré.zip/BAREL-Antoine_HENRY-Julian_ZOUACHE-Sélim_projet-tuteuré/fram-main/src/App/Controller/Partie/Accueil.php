<?php

namespace App\Controller\Partie;

use Database\DBConnection;
use Framework\Controller\AbstractController;
use PDO;

class Accueil extends AbstractController
{
    public function __invoke(): string
    {
        $connection = DBConnection::getConnection();

        $stmt = $connection->prepare('SELECT COUNT(*) FROM Info');
        if ($stmt->execute()) {
             $nb = $stmt->fetch(PDO::FETCH_ASSOC);
        }

        $rand = random_int(1,$nb['COUNT(*)']);
        

        $stmt = $connection->prepare('SELECT `Info_label` FROM Info WHERE Info_id = :nb');
        $stmt->bindParam('nb', $rand, PDO::PARAM_STR);
        if ($stmt->execute()) {
             $info = $stmt->fetch(PDO::FETCH_ASSOC);
        }



        return $this->render('jeu/accueil.html.twig', [
            'info' => $info['Info_label']
        ]);

        $connection = DBConnection::getConnection();

        $stmt = $connection->prepare('SELECT username,firstname,lastname,email from users WHERE WHERE username = :username');
        
        if ($stmt->execute()) {
            $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
       }

        var_dump($users);
        
       return $this->render(
            'jeu/accueil.html.twig', 
           [
             'users' => $users,
           ]);

        
    }
}
