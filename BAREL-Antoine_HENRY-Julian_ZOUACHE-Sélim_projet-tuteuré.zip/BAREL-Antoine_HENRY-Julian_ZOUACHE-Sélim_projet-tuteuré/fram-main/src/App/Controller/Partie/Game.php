<?php

namespace App\Controller\Partie;

use App\Controller\Admin\PassAdmin;
use Database\DBConnection;
use Framework\Controller\AbstractController;
use PDO;

class Game extends AbstractController
{
    public function __invoke(): string
    {
        // $PassAdmin = new PassAdmin;
        // $PassAdmin->Control();

        

        //Sélect Level :

        
        return $this->render('jeu/game.html.twig', [
            'Affichelvl' => true,
            'AfficheGrille' => true
        ]);
        
    }
}
