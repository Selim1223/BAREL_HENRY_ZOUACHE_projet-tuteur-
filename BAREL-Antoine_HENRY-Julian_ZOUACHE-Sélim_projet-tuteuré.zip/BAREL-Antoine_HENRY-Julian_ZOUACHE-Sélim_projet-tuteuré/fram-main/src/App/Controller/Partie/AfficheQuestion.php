<?php

namespace App\Controller\Partie;

use App\Controller\Admin\PassAdmin;
use Database\DBConnection;
use Framework\Controller\AbstractController;
use PDO;
session_start();

class AfficheQuestion extends AbstractController
{
    public function __invoke(int $lvl): string
    {
        // $PassAdmin = new PassAdmin;
        // $PassAdmin->Control();
        if ($this->isPost()) {

            //Vérify réponse
            if (!empty($_POST['choice']) && $_POST['choice'] == $_SESSION['Reponse_juste']) {
                echo 'Réponse juste';
                //tableau -> avancer
                header("location: /index/jeu/game");
            }
            else if (!empty($_POST['choice']) && $_POST['choice'] != $_SESSION['Reponse_juste']) {
                //tableau -> reculer
                echo 'Réponse fausse';
                header("location: /index/jeu/game");
            }
            
        }

        $bdd = DBConnection::getConnection();

        //Compte le nombre de question du Niveau choisi
        $stmt = $bdd->prepare('SELECT COUNT(*) FROM question WHERE Niveau = :lvl');
        $stmt->bindParam('lvl', $lvl, PDO::PARAM_STR);
        if ($stmt->execute()) {
            //var_dump($stmt->fetchAll(PDO::FETCH_ASSOC));
             $nb_question = $stmt->fetch(PDO::FETCH_ASSOC);
        }

        $quesiton = random_int(0,$nb_question['COUNT(*)']);

        $SelectQuestion = $lvl*100 + $quesiton;

        $stmt = $bdd->prepare('SELECT Question_id, Question_label,Reponse_label FROM question INNER JOIN reponse ON question.Question_id = reponse.Reponse_id WHERE Question_id <= :nb ORDER BY Question_id Desc
        LIMIT 0,1');
        $stmt->bindParam('nb', $SelectQuestion, PDO::PARAM_STR);
        if ($stmt->execute()) {
            //var_dump($stmt->fetchAll(PDO::FETCH_ASSOC));
             $InfoQuestion = $stmt->fetch(PDO::FETCH_ASSOC);
        }

        $Reponses = explode(' -- ', $InfoQuestion['Reponse_label']);

        $NB_reponse = count($Reponses);

        $_SESSION['Reponse_juste'] = $Reponses[0];

        var_dump($_SESSION['Reponse_juste']);
        shuffle($Reponses);
        
        

        return $this->render('jeu/game.html.twig', [
            'NB_reponse' => $NB_reponse,
            'Reponses' => $Reponses,
            'question' => $InfoQuestion['Question_label'],
            'Affichelvl' => false,
            'AfficheGrille' => false
        ]);
        
    }
}
