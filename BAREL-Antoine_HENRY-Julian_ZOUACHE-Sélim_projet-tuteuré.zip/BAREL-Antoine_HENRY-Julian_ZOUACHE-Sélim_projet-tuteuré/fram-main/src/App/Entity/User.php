<?php

namespace App\Entity;

use Database\DBConnection;

class User
{
  protected $username;
  protected $firstName;
  protected $lastName;
  protected $email;
  protected $MDP;


  public function __construct(string $username, string $MDP ,string $firstName, string $lastName, string $email){
    $this->username = $username;
    $this->MDP = $MDP;
    $this->firstName = $firstName;
    $this->lastName = $lastName;
    $this->email = $email;

  }

  public function getUsername() :string
  {
    return $this->username;
  }

  // Vérificaiton
  // Si tout est bon -> envoie BDD SINON return ce qui va dans le controller

  public function verify(string $username, string $MDP, string $MDPV ,string $firstName, string $lastName, string $email)
  {
    
    $errors = [];
    $correct = [];
    

    $tab = [ 'username' => $username, 'MDP' => $MDP, 'MDPV' =>  $MDPV , 'firstName' => $firstName, 'lastName' => $lastName, 'email' => $email];
    
      $validations = [
          'username' => [
              'rules' => [
                  ['name' => 'required'],
                  ['name' => 'maxlength', 'value' => 20],
                  ['name' => 'isString'],
                  ['name' => 'unique', 'ErrorMessage' => 'Utilisateur déjà existant !'],
              ]
          ],
          'MDP' => [
              'rules' => [
                  ['name' => 'required'],
                  ['name' => 'maxlength', 'value' => 100]
              ]
          ],
          'MDPV' => [
              'rules' => [
                  [
                    'name' => 'sameAs',
                    'field' => 'MDP',
                    'ErrorMessage' => 'Les mots de passe doivent correspondre'
                  ],
              ]
          ],
          'firstName' => [
              'rules' => [
                  ['name' => 'required'],
                  ['name' => 'maxlength', 'value' => 100]
              ]
          ],
          'lastName' => [
              'rules' => [
                  ['name' => 'required'],
                  ['name' => 'maxlength', 'value' => 100]
              ]
          ],
          'email' => [
              'rules' => [
                  ['name' => 'required'],
                  ['name' => 'maxlength', 'value' => 100],
                  ['name' => 'email'],
              ]
          ]
      ];
    

    foreach ($validations as $fieldName => $params) {
      foreach ($params['rules'] as $rule) {
        foreach ($tab as $ele => $val) {
        
          switch ($rule['name']) {
              case 'required':
                  if ($fieldName == $ele && $val == '') {
                      $errors[$fieldName][] = 'Le champs est obligatoire';
                  }
                  break;
              case 'maxlength':
                  if ( $fieldName == $ele && strlen($val) > $rule['value']) {
                      $errors[$fieldName][] = 'La valeur de ce champs ne doit pas dépasser ' . $rule['value'] . ' caractères !';
                  }
                  break;
              case 'email':
                  if ( $fieldName == $ele && !filter_var($val, FILTER_VALIDATE_EMAIL)) {
                      $errors[$fieldName][] = 'Ce champs doit contenir une adresse email valide !';
                  }
                  break;
              case 'sameAs':
                
                  if ($fieldName == $ele && $val !== $tab['MDP']) {
                      $errors[$fieldName][] = $rule['ErrorMessage'];
                  }
                  break;
             
              case 'isString':
                  if ($fieldName == $ele && !is_string($val)) {
                      $errors[$fieldName][] = 'Ce champs doit etre une chaine de caractères !';
                  }
                  break;
              case 'unique':
                $isUnique = new DBConnection();
                  if ($fieldName == $ele && $isUnique->userExist($val)) {
                      $errors[$fieldName][] = $rule['ErrorMessage'] ?? 'Entité déjà existante !';
                  }
                  break;
          }
        }
      }
  }
  
  

  $correct = array_diff_key($tab, $errors);

  $result = [
    $errors,
    $correct
  ];
  //var_dump($result);
    

    if (empty($errors)) {
      $isRegistered = new DBConnection();
      $isRegistered -> registerUser([  
              'username' => $username,
              'password' => $MDP,
              'first_name' => $firstName,
              'last_name' => $lastName,
              'email' => $email
      ]);
      echo("<script>console.log('enregistré');</script>");
    }
    else{
      echo("<script>console.log('PAS enregistré');</script>");
      return $result;

    }

      if ($isRegistered) {
        echo("<script>console.log('bon');</script>");
    } else {
      echo("<script>console.log('pas bon');</script>");
    }
  }
  
}

