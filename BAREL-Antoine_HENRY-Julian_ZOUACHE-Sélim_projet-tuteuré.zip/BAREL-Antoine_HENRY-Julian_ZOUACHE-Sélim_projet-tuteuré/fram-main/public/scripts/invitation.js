function getSelectValue(selectID1)
{
    if(selectID1!=""){
        $("#selectID2 option[value='"+ selectID1 +"']").hide();
        $("#selectID3 option[value='"+ selectID1 +"']").hide();
        $("#selectID4 option[value='"+ selectID1 +"']").hide();
        $("#selectID5 option[value='"+ selectID1 +"']").hide();
        $("#selectID6 option[value='"+ selectID1 +"']").hide();
        $("#selectID1 option[value='"+ selectID1 +"']").hide();
    }  
}




