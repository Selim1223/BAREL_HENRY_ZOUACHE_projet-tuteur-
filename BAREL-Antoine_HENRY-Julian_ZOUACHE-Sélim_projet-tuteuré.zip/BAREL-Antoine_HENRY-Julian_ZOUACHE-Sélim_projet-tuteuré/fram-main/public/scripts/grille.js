sessionStorage.setItem('Position1', 1);
sessionStorage.setItem('Position2', 4);
sessionStorage.setItem('Position3', 8);

function myFunction1() {
const nbLignes = 1;
const nbColonnes = 49;

for (let i = 0; i < nbLignes; i++) {
    const trElet = document.createElement('tr');
    trElet.id = 'line-' + i;
    document.querySelector('#myTab1').appendChild(trElet);

    for (let j = 0; j < nbColonnes; j++) {
    const tdElet = document.createElement('td');
    tdElet.id = j + '-' + i;
    if(sessionStorage.getItem('Position1') == j){
        tdElet.style.backgroundColor = "cyan"
    }
    document.getElementById(`line-${i}`).appendChild(tdElet);
    }
}

}

function myFunction2() {
const nbLignes = 1;
const nbColonnes = 49;

for (let i = 0; i < nbLignes; i++) {
    const trElet = document.createElement('tr');
    trElet.id = 'line-' + i;
    document.querySelector('#myTab2').appendChild(trElet);

    for (let j = 0; j < nbColonnes; j++) {
    const tdElet = document.createElement('td');
    tdElet.id = j + '-' + i;
    if(sessionStorage.getItem('Position2') == j){
        tdElet.style.backgroundColor = "red"
    }
    document.getElementById(`line-${i}`).appendChild(tdElet);
    }
}
}

function myFunction3() {
const nbLignes = 1;
const nbColonnes = 49;

for (let i = 0; i < nbLignes; i++) {
    const trElet = document.createElement('tr');
    trElet.id = 'line-' + i;
    document.querySelector('#myTab3').appendChild(trElet);

    for (let j = 0; j < nbColonnes; j++) {
    const tdElet = document.createElement('td');
    tdElet.id = j + '-' + i;
    if(sessionStorage.getItem('Position3') == j){
        tdElet.style.backgroundColor = "black"
    }
    document.getElementById(`line-${i}`).appendChild(tdElet);
    }
}
}


function addLoadEvent(func) {
let oldonload = window.onload;
if (typeof window.onload != 'function') {
    window.onload = func;
} else {
    window.onload = function () {
    if (oldonload) {
        oldonload();
    }
    func();
    }
}
}


addLoadEvent(myFunction3);
addLoadEvent(myFunction2);
addLoadEvent(myFunction1);