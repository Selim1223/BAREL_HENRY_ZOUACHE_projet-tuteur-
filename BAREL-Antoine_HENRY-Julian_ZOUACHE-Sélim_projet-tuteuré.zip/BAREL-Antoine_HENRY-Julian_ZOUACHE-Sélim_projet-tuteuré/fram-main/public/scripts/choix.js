function btnn(btn) {
                
    if(btn.className == 'btn btn-secondary'){
        btn.className = 'btn btn-primary';
        
        btn.name = 'choice';
        console.log('Second to primary :' + btn.name);
        Verify(btn)
    }
    else {
        btn.className = 'btn btn-secondary';
        btn.name = 'NotChoice';
        console.log('prim to second :' + btn.name);
    }
}

function Verify(btn){
console.log(btn);
let prim = document.getElementsByClassName('btn btn-primary')



if(prim.item(1)!=null && prim.item(1)==btn){
    prim.item(0).className = 'btn btn-secondary';
}
else if(prim.item(1)!=null && prim.item(1)!=btn){
    prim.item(1).className = 'btn btn-secondary';
}
}
